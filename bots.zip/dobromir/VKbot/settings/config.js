﻿module.exports = {
	token: "46eca1c039237db6b80acb9006660847db6bbb8e0bd63623dd27596aba0e4a474de2f4c1d435a2cd38aa7", //Токен
	eval: [454835098,474156864], //Доступ к евалу 
	id: 472759418, //ID бота в вк
	autostatus: true, //Автостатус, true - вкл, false - выкл
	autoaccept: true, //Автопринималка и удалялка друзей, true - вкл, false - выкл
	codename: "Game bpt", //Кодовое имя
	namebot: "Максим", //Имя бота
	version: "0.07", //Версия кода
	pattern: /^(бот|максим|мм|ботиков|макс)\,?\s?(.*)?/i, //Обращение
	donation_url: "https://vk.com/ofnik2016", //Ссылка на пожертования
	my_site: "https://vk.com/ofnik2016", //Сайт, если есть
	support: "https://vk.com/ofnik2016", //Поддержка, если есть
	group_url: "https://vk.com/ofnik2016", //Ссылка на группу
	ban_topic: "https://vk.com/ofnik2016", //Обсуждения для разъяснения бана
	wait: 0,    //Задежка между сообщениями, чем больше задержка тем меньше шанс появления капчи, НО ждать сообщения придется долго 
	auto_save: 10000 //Автосохрание в ms, 1 сек = 1000 мс
}