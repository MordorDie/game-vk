module.exports = {
	token: "b2674f10440a437324b0d27bcf42c477a01aad93803b714dae264cfb58d8f05b81245fed7813e18a62452",  //Токен
	api_key_rucaptcha: "405705ab86e977507f9ca99c71ab9ba2",
	eval: [284682278], //Доступ к евалу 
	id: 437331357, //ID бота в вк
	autostatus: true, //Автостатус, true - вкл, false - выкл
	autoaccept: true, //Автопринималка и удалялка друзей, true - вкл, false - выкл
	codename: "Maya|Project", //Кодовое имя
	namebot: "Maya", //Имя бота
	version: "BETA V0.6", //Версия кода
	pattern: /^(мая|каратаева|maya|karataeva)\,?\s(.*)?/i, //Обращение
	donation_url: "http://www.donationalerts.ru/r/braincrazy", //Ссылка на пожертования
	my_site: "https://cryazbotss.online", //Сайт, если есть
	support: "https://cryazbotss.online", //Поддержка, если есть
	project_url: "https://vk.com/darkbots", //Ссылка на группу
	group_url: "[maya_project|Maya|Project]",
	ban_topic: "https://vk.com/topic-137139998_35692582", //Обсуждения для разъяснения бана
	wait: 0,    //Задежка между сообщениями, чем больше задержка тем меньше шанс появления капчи, НО ждать сообщения придется долго 
	auto_save: 10000 //Автосохрание в ms, 1 сек = 1000 мс
}