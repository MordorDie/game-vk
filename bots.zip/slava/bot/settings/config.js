module.exports = {
    id: 464579039, //Айди бота
    token: "36060402cbdbbb9cae60138c338c391e2a1594bcc84523091d136f90b834b964b2ef3a88a33950f177fd0", //Токен
    pattern: /^(слава|slava)\,?\s?(.*)?/i, //Обращение
    project: 'HypeBot',
    bot: 'Слава',
    developers: 'https://vk.com/id406749868 https://vk.com/briancrazy228',
    group: 'https://vk.com/slavakpssbot',
    group_project: 'https://vk.com/hypebots228'
}