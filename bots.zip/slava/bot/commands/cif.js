module.exports = {
    r: /(cif|чат|беседа) ([0-9]+)/i,
    f: (msg, args, vk, bot) => {
            if(args[2] == 0) return
            vk.messages.getChat({
                chat_id: args[2],
                fields: "sex"
            }).then((res) => {
                if(res.admin_id == 0) return bot({text:"Такой беседы не существует!", status: true, type: "send"});
                if(!res.users[0]) return bot({text:"Меня кикнули из этой беседы", status: true, type: "send"});
                bot({text:" 📰 | Информация по беседе "+ args[2] +"| ￼🔑 Название беседы: "+ res.title +"\n￼👹 | Создатель беседы: *id"+res.admin_id+"\n￼😎 | Пользователи беседы (Всего: "+ res.users.length + " пользователей): \n"+ res.users.map(a=> "[id" + a.id + "|" + a.first_name + " " + a.last_name + "]").join(', '), status: true, type: "send", n: true});
            })
        },
	rights: 3,
    desc: "🎫 | беседа <<ID чата>> -- информация о беседе"
}