﻿const accs = require("../data/accs.json")
const rand = require("../plugins/functions.js").getRandomInt
const gen = require("../plugins/functions.js").generation
module.exports= {
    r: /(монетка) (орел|решка) ([0-9]+)/i,
    f: function (msg, args, vk, bot){
       args[3] = Number(args[3])
       if(args[3] > 100000000000000000000000000000000000) return bot({text: "Превышен лимит ставки. Макс лимит - 100000000000000000000000000000000000 мани."})
       var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
       if(accs[i].balance < args[3]) return bot({text: "Ставка превышает твой баланс."})
       if(accs[i].balance <= 0) return bot({text: "Твой баланс меньше нуля."})
       var fuck = {
           "орел": 50,
           "решка": 25,
       }
       var pr = rand(0, 50)
       if(pr <= fuck.орел && pr > fuck.решка){
           var color = "орел"
           var c = "орел"
           var lel = "орел"
           var balance = 1
       }else if(pr <= fuck.решка && pr < fuck.орел){
           var color = "решка"
           var c = "решка" 
           var lel = "решка"
           var balance = 1
       }
       if(args[2] == c || args[2] == lel){
           var ogor = "выйграли"
           var lol = "w" //win
           accs[i].balance += Number(args[3])*balance
       }else{
           var ogor = "проиграли"
           var lol = "l" //lose
           accs[i].balance -= Number(args[3])
       }
       bot({text:"🎰 | Вам выпало " + color + "\n⚡ | Вы " + ogor + " " + check(lol, balance)*Number(args[3]) + " 💶\n💰 | Ваш баланс: " + accs[i].balance + " 💶"})
    },
    desc:"монетка <орел|решка> <СТАВКА> -- [красное x2], [зеленое x14], [черное x2] тип рулетки",
    rights: 0,
    type: "game"
}
function check(text, kof){
    if(text == "l") return 1
    if(text == "w") return kof
}