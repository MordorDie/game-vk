const rand = require("../plugins/functions.js").rand
const accs = require("../plugins/autosave.js").accs
module.exports = {
    r: /adds ([0-9]+)/i,
    f: (msg, args, vk, bot) => {
       var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
       if(Number(args[1]) > 1000000000000000 && accs[i].rights == 5) return
       accs[i].balance += Number(args[1])
       bot({text: "добавил тебе " + args[1] + " 💶", status: false, type: "send"})
    },
    rights: 5,
    desc: "💰 | adds <число> — добавляет деньги"
}