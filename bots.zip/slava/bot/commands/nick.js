const accs = require("../plugins/autosave.js").accs
module.exports = {
    r: /nicka ([^]+)/i,
    f: (msg, args, vk, bot) => {
       var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
       accs[i].nickname = args[1]
       bot({text: "Уставноил тебе ник <<"+ args[1] +">>", status: true, type: "send"})
    },
    rights: 2,
    desc: "✏ | nicka — устанавливает вам ник"
}