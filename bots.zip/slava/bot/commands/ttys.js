const accs = require("../plugins/autosave.js").accs
module.exports = {
    r: /ttys/i,
    f: (msg, args, vk, bot) => {
      vk("messages.getById", {message_ids: msg.id}).then((response) => {
       if(!accs.some(a=> a.id == response.items[0].fwd_messages[0].user_id)) return bot({text: "Пользователя нет в базе", status: true, type: "send"})
       var i = accs.filter(a=> a.id == response.items[0].fwd_messages[0].user_id).map(a=> a.uid)
       accs[i].balance = 500
       bot({text: "Обнулил счет!", status: true, type: "send"})
      })
    },
    rights: 6,
    desc: "💥 | ttys обнуляет человеку счёт"
}