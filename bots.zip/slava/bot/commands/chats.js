const funct = require("../plugins/functions.js")
module.exports = {
	r: /(чаты|все чаты|allchats|chats|беседы)/i,
	f: function (msg, args, vk, bot){
        vk("messages.getDialogs", {count: 50}).then((res) => {
        var gone = res.items.filter(a=> a.message.chat_id && a.message.chat_active.length > 0 && a.message.users_count > 0).map(a=> `[${a.message.users_count}/250] <ID: ${a.message.chat_id}> ${a.message.title}`).join("\n")
		return bot({text: gone, status: true, type: "send", n: true})
	})
	},
	rights: 1,
	desc: "чаты -- все беседы бота",
	type: "all",
	typ: "prosto"
}