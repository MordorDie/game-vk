const accs = require("../plugins/autosave.js").accs
const getRandomInt = require("../plugins/functions.js").getRandomInt
module.exports = {
	    r: /(kosti|кости) ([0-9]+)/i,
	    f: function (msg, args, vk, bot){
		   var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
           var spot = Number(args[2])
           if(spot == 0) return
		   if(accs[i].balance < spot) return bot({text: "Ты ставишь больше, чем свой баланс."})
		   if(accs[i].balance <= 0) return bot({text: "Извини, но у тебя " + accs[i].balance + " 💶"})
           var my = getRandomInt(1, 6)
           var boting = getRandomInt(1, 6)
		   const check = my > boting ? false : true
		   const ogo = my == boting ? false : true
		   var atts = check == true ? 'photo-159218514_456239033' : (ogo == false ? '' : 'photo-159218514_456239032')
		   ogo == true ? (check == true ? accs[i].balance -= spot : accs[i].balance += spot) : null
           const gone = ogo == true ? (check == true ? `🎲 | Тебе выпало - ${my}.\n🎲 | Мне выпало -  ${boting}.\nУра! Я победил(а) тебя и забираю ${spot} 💶 \n💰 | Твой баланс: ${accs[i].balance} 💶` : `🎲 | Тебе выпало - ${my}.\n🎲 | Мне выпало -  ${boting}.\nТы победил меня и забираешь ${spot} 💶 \n💰 | Твой баланс: ${accs[i].balance} 💶`) : `🎲 | Тебе выпало - ${my}.\n🎲 | Мне выпало -  ${boting}.\nУ нас ничья! \n💰 | Твой баланс: ${accs[i].balance} 💶`
		   bot({text: gone, status: true, type: "send", att: atts})
		},
		desc: "🎲 | кости <СТАВКА> — игра «Кости»",
		rights: 0
}