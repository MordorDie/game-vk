module.exports = {
    r: /о боте/i,
    f: (msg, args, vk, bot) => {
       const config = require('../settings/config.js')
       const main = require('../core.js')
       bot({text: `✏ | Основная информация: 
       💻 | Проект: ${config.project}
       ⚙ | Название бота: ${config.bot}
       🔧 | Разработчики: ${config.developers}
       🎎 | Группа: ${config.group}
       👪 | Группа проекта: ${config.group_project}
       
       📝 | Статистика:
       💾 | Всего команд: ${main.cmds}
       🐶 | Всего пользователей: ${require('../data/accs.json').length}
       🐔 | Банлист: ${require('../data/banlist.json').filter(a=> a.status == true).map(a=> a).length}
       
       🎃 | Статистика привелегий
       
       ⚡ | Всего випов: ${require('../data/accs.json').filter(a=> a.rights == 1).map(a=> a).length}
       🎁 | Всего супер випов: ${require('../data/accs.json').filter(a=> a.rights == 2).map(a=> a).length}
       🎧 | Всего тестеровщиков: ${require('../data/accs.json').filter(a=> a.rights == 3).map(a=> a).length}
       👮 | Всего модераторов: ${require('../data/accs.json').filter(a=> a.rights == 4).map(a=> a).length}
       🔑 | Всего администраторов: ${require('../data/accs.json').filter(a=> a.rights == 5).map(a=> a).length}`, status: true, type: "send", n: true})
    },
    rights: 0,
    desc: "о боте -- общая инфомарция о боте"
}