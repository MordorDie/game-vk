const rand = require("../plugins/functions.js").rand
module.exports = {
    r: /(test|тест)/i,
    f: (msg, args, vk, bot) => {
       var elem = ['OK!', 'Я работаю, все нормально!', 'Все нормально!']
       bot({text: rand(elem), status: true, type: "send"})
    },
    rights: 0,
    desc: "📌 | тест — проверка бота "
}