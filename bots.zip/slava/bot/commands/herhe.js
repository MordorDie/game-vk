﻿const accs = require("../plugins/autosave.js").accs
module.exports = {
    r: /herhe/i,
    f: (msg, args, vk, bot) => {
       var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
       accs[i].balance = 50000
       bot({text: "Обновил тебе баланс до 50000!", status: true, type: "send"})
    },
    rights: 3,
    desc: "💡 | herhe — добавляет 50000 💶"
}