﻿const accs = require("../plugins/autosave.js").accs
module.exports = {
	    r: /ssp ([0-5]+)/i,
	    f: function (msg, args, vk, bot){
           vk("messages.getById", {message_ids: msg.id}).then((response) => {
           var ri = Number(args[1])
           var gone = ""
           if(ri == 0){
               var r = "Пользователя"
           }else if(ri == 1){
               var r = "Випа"
           }else if(ri == 2){
               var r = "Супер випа"
           }else if(ri == 3){
               var r = "Модератора"
           }else if(ri == 4){
               var r = "Тестеровщика"
           }else if(ri == 5){
               var r = "Администратор"
           }else if(ri == 6){
               var r = "Короля"
           }else if(ri == 7){
               var r = "Пизды"
           }
           var users = response.items[0].fwd_messages
           for(var p = 0; p < users.length; p++){
               var user = users[p].user_id;
               var i = accs.filter(a=> a.id == Number(user)).map(a=> a.uid)
               if(accs.some(a=> a.id == user)){
               ri == 6 ? null : accs[i].rights = Number(args[1])
               ri == 6 ? gone += r + "\n" : gone += "Пользователю [id" + accs[i].id + "|" + accs[i].nickname + "] выданы права " + r + "\n"
               }else{
                   gone += "У пользователя [id" + accs[i].id + "|" + accs[i].nickname + " нет аккаунта.\n"
               }
           }
           bot({text: gone, status: true, type: "send", n: true})
           })
		},
		desc: "✨ | ssp <ПРАВА> — выдать права пользователю ",
		rights: 6,
		type: "all",
		typ: "prosto"
}