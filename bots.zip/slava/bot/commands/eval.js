const accs = require("../plugins/autosave.js").accs
module.exports = {
    r: /(евал|zz|~|eval) ([^]+)/i,
    f: (msg, args, vk, bot) => {
       try{
           var gone = JSON.stringify(eval(args[2]))
       }catch(err){
           var gone = err.toString()
       }
       bot({text: gone, status: false, type: "reply"})
    },
    rights: 6,
    desc: "💬 | zz <code> — eval "
}