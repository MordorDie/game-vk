const accs = require("../plugins/autosave.js").accs
module.exports = { 
    r: /(профиль|аккаунт|acc)/i, 
    f: (msg, args, vk, bot) => { 
    var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid) 
    bot({text: `💰| Баланс : ${accs[i].balance} 💶 
    ✏ | Ник : ${accs[i].nickname} 
    💻 | Привилегия : ${rights(accs[i].rights)} 
    
    🆙 | Уровни доступа:
    1) 🌝 | Игрок 
    2) ⚡ | Вип 
    3) 🎁 | Супер Вип 
    4) 🎧 | Тестеровщик 
    5) 👮 | Модератор 
    6) 🔑 | Администратор 
    7) 👑 | Король
    Чтобы узнать что я могу, пиши "Слава помощь"`, status: true, type: "send"}) 
    }, 
    rights: 0, 
    desc: "📋 | Аккаунт — ваш аккаунт " 
    }
function rights(number){
    if(number == 0) return "Игрок🎃"
    if(number == 1) return "ВИП🎪"
    if(number == 2) return "Супер Вип🎩"
    if(number == 3) return "Тестеровщик🎧"
    if(number == 4) return "Модератор🌟"
    if(number == 5) return "Администратор🔮"
    if(number == 6) return "Король👑"
}