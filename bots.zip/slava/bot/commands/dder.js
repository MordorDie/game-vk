﻿const accs = require("../plugins/autosave.js").accs
module.exports = {
    r: /dder/i,
    f: (msg, args, vk, bot) => {
       var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
       accs[i].balance = 10000
       bot({text: "Обновил тебе баланс до 10000!", status: true, type: "send"})
    },
    rights: 2,
    desc: "🃏 | dder — добавляет 10 000 💶"
}