﻿const accs = require("../plugins/autosave.js").accs
const getRandomInt = require("../plugins/functions.js").getRandomInt
const rand = require("../plugins/functions.js").rand
module.exports = {
	    r: /(spot|спот|рулетка) ([0-9]+)/i,
	    f: function (msg, args, vk, bot){
		   var i = accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
		   var spot = Number(args[2])
		   if(spot == 0) return
		   if(accs[i].balance < spot) return bot({text: "Ты ставишь больше, чем свой баланс."})
		   if(accs[i].balance <= 0) return bot({text: "Извини, но у тебя " + accs[i].spots + " ботсов."})
		   var check = rand([true, false])
		   var atts = check == true ? 'photo-159218514_456239033' : 'photo-159218514_456239032'
		   check == true ? accs[i].balance -= spot : accs[i].balance += spot
		   const gone = check == true ? `😢 Ой! Ты проиграл ${spot} 💶\n💰 Твой баланс: ${accs[i].balance} 💶` : `😉 Ура! Ты выиграл ${spot} 💶\n💰 Твой баланс: ${accs[i].balance} 💶`
		   bot({text: "\n" + gone, att: atts})
		},
		desc: "🎰 | рулетка <СТАВКА> — рулетка ",
		rights: 0
}