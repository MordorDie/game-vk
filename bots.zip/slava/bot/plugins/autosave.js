var accs = require("../data/accs.json")
var banlist = require("../data/banlist.json")
const fs = require("fs")
function saving(){
	console.log("Autosave starting...")
    fs.writeFileSync("./data/accs.json", JSON.stringify(accs, null, "\t"))
    fs.writeFileSync("./data/banlist.json", JSON.stringify(banlist, null, "\t"))
    console.log("Autosave completed!")
}
module.exports = {
    accs,
    banlist,
    saving
}