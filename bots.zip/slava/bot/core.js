const config = require("./settings/config.js")
const logger = require("./plugins/console.js").Logger
const fs = require("fs")
const cmds = fs.readdirSync("./commands").filter(x => x.endsWith(".js")).map(x => require("./commands/" + x));
const funct = require("./plugins/functions.js")
const autosave = require("./plugins/autosave.js")
const systems = require("./plugins/systems.js")

//Прочие модули
const vk = require("VK-Promise")(config.token)
vk.init_longpoll()
var main = {
    cmds: 0
}
vk.on("message", (event, msg) => {
     if(config.id == msg.from_id) return
     var banlist = autosave.banlist
	 if(banlist.some(a=> a.id == msg.from_id && a.status == true) == true) return
     if(!autosave.accs.some(a=> a.id == msg.from_id)){
        autosave.accs.push({
            id: msg.from_id, 
            balance: Number(new Date().getFullYear()), 
            nickname: "Пользователь", 
            rights: 0,
            uid: autosave.accs.length
        })
		vk.users.get({user_ids: msg.from_id})
		.then((res) => {
			var i = autosave.accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
			autosave.accs[i].nickname = res[0].first_name
		})
    }
     var i = autosave.accs.filter(a=> a.id == msg.from_id).map(a=> a.uid)
     msg.chat_id ? logger('info', [__filename, 'CHAT', msg.title, "CHAT ID: " + msg.chat_id, "FROM: " + msg.from_id, msg.body]) : logger('info', [__filename, 'USER', "FROM: " + msg.from_id, msg.body])
     cmds.map((cmd) => {
         try{
            if(!config.pattern.test(msg.body)) return;
            var patt = msg.body.match(config.pattern)
            var body = patt[2]
            if(!cmd.r.test(body)) return
            if(cmd.rights > autosave.accs[i].rights) return
            const args = body.match(cmd.r) || [];
            args[0] = msg
            main.cmds++
            cmd.f(msg, args, vk, (bot) => {
                 if(!bot.n){
                     var t = bot.text.replace(/([0-9]+)/ig, replacer)
                 }else{
                     var t = bot.text
                 }
                 bot.type == 'reply' ? msg.reply(t, {attachment: bot.att}) : msg.send(t, {attachment: bot.att})
            })
         }catch(err){
            msg.chat_id ? logger('error', [__filename, 'CHAT', msg.title, "CHAT ID: " + msg.chat_id, "FROM: " + msg.from_id, err]) : logger('error', [__filename, 'USER', "FROM: " + msg.from_id, err])
         }
     })
})
setInterval(() => {
    vk("account.setOnline", {voip: 0})
    vk.friends.getRequests({out: 0, extended: 0, need_mutual: 0})
	.then((r) => {
		 if(r.items.length == 0) return
		 for(var y = 0; y < r.items.length; y++){
			 vk.friends.add({user_id: r.items[y]})
		 }
	})
	vk.friends.getRequests({out: 1, extended: 0, need_mutual: 0})
	.then((r) => {
		if(r.items.length == 0) return
		for(var y = 0; y < r.items.length; y++){
			vk.friends.delete({user_id: r.items[y]})
		}
   })
   autosave.saving()
}, 20000)
var replacer = (a) => {
    return (a + "").split("").reverse().join("").replace(/(\d{3})/g, "$1 ").split("").reverse().join("").replace(/^ /, "");
}
setInterval(() => {
    systems.forbans()
}, 1000)
module.exports = main